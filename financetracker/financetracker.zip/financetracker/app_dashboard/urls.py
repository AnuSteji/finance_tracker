from django.urls import path
from app_dashboard import views


app_name="app_dashboard"

urlpatterns = [
    path("admindashboard/", views.admindashboard, name="admindashboard"),
]